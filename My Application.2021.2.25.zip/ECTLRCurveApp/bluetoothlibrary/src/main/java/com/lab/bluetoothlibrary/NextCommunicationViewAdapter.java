package com.lab.bluetoothlibrary;



public class NextCommunicationViewAdapter implements INextViewAdapter {

    @Override
    public void action() {
    }
}