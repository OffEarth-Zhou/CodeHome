package com.lab.bluetoothlibrary;

public interface IBluetoothUtil {

    void addBluetoothConnectPresenter(BluetoothConnectPresenter presenter);

    void init();

    void  connenct();

    void setCurDeviceIndex(int curDeviceIndex);

    void sendMessage(String message);

    void sendMessage(byte[] message);

    void addBluetoothCommunicationPresenter(BaseBluetoothCommunicationPresenter presenter);
}
