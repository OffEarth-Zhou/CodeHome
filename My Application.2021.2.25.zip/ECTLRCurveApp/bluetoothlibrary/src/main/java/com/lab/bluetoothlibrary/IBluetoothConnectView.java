package com.lab.bluetoothlibrary;

import java.util.ArrayList;

public interface IBluetoothConnectView {

    void updateDeviceNameList(ArrayList<String> deviceNameList);

    void addPresenter(BluetoothConnectPresenter presenter);

    void isConnectDone(boolean stutas);
}
