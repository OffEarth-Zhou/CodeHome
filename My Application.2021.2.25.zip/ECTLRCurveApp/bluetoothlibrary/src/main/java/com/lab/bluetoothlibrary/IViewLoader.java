package com.lab.bluetoothlibrary;

import android.content.Context;

public interface IViewLoader {

    void loadBluetoothConnectView(Context context);
    void loadBluetoothCommunicationView();

}
