package com.lab.bluetoothlibrary;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Set;
import java.util.ArrayList;
import java.util.UUID;


public class BluetoothControl implements IBluetoothUtil {

    // 蓝牙控制表示器
    private BluetoothConnectPresenter myBluetoothConnectPresenter;
    private BaseBluetoothCommunicationPresenter myBluetoothCommunicationPresenter;
    // 蓝牙通讯适配器
    private BluetoothAdapter blueadapter;

    private Set<BluetoothDevice> pairedDevices;
    //定义一个列表，存蓝牙设备的地址。
    private ArrayList<String> deviceMacList = new ArrayList<>();
    //定义一个列表，存蓝牙设备地址，用于显示。
    private ArrayList<String> deviceNameList = new ArrayList<>();

    private static BluetoothSocket mSocket = null;

    private int curDeviceIndex;

    private static class HolderClass {
        private final static BluetoothControl instance = new BluetoothControl();
    }

    public static BluetoothControl getInstance() {
        return HolderClass.instance;
    }

    public void addBluetoothCommunicationPresenter(BaseBluetoothCommunicationPresenter presenter) {
        this.myBluetoothCommunicationPresenter = presenter;
    }

    public void addBluetoothConnectPresenter(BluetoothConnectPresenter presenter) {
        this.myBluetoothConnectPresenter = presenter;
    }

    // 初始化
    public void init() {
        blueadapter = BluetoothAdapter.getDefaultAdapter();
        if (!blueadapter.isEnabled()) {
            //如果没打开，则打开蓝牙
            blueadapter.enable();
            myBluetoothConnectPresenter.setBluetoothEnable(blueadapter.isEnabled());
        }
        try {
            if (blueadapter.isEnabled()) {
                pairedDevices = blueadapter.getBondedDevices();
                deviceMacList.clear();
                deviceNameList.clear();
                if (pairedDevices.size() > 0) {
                    for (BluetoothDevice device : pairedDevices) {
                        deviceNameList.add(device.getName());
                        deviceMacList.add(device.getAddress());
                    }
                    myBluetoothConnectPresenter.setDeviceNameList(deviceNameList);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void connenct() {
        if (pairedDevices.size() > 0) {
            String macAddr = deviceMacList.get(curDeviceIndex);
            final BluetoothDevice device = blueadapter.getRemoteDevice(macAddr);

            new Thread() {
                @Override
                public void run() {
                    try {
                        if (mSocket != null) {
                            mSocket.close();
                        }
                        if (blueadapter.isDiscovering()) {
                            blueadapter.cancelDiscovery();
                        }
                        myBluetoothConnectPresenter.isConnectDone(false);
                        mSocket = (BluetoothSocket) device.getClass()
                                .getDeclaredMethod("createRfcommSocket", new Class[]{int.class})
                                .invoke(device, 1);
                        new Thread() {
                            @Override
                            public void run() {
                                try {
                                    mSocket.connect();
                                    myBluetoothConnectPresenter.isConnectDone(true);
                                    new Thread() {
                                        @Override
                                        public void run() {
                                            byte[] buffer = new byte[1024];
                                            int bytes;
                                            while (true) {
                                                try {
                                                    bytes = mSocket.getInputStream().read(buffer);
                                                    if (bytes > 0) {
                                                        myBluetoothCommunicationPresenter.receiveMessage(bytes, buffer);
                                                    }
//                                            Thread.sleep(20);
                                                } catch (Exception ex) {
                                                }
                                            }
                                        }
                                    }.start();
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }.start();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }.start();
        }
    }

    public void setCurDeviceIndex(int curDeviceIndex) {
        this.curDeviceIndex = curDeviceIndex;
    }

    @Override
    public void sendMessage(String message) {
        try {
            OutputStream outputStream = mSocket.getOutputStream();
            if (outputStream != null) {
                byte[] bytes = message.getBytes();
                outputStream.write(message.getBytes());
            } else {
//                Toast.makeText(getApplicationContext(), "为NULL流", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException ex) {

            ex.printStackTrace();
        }
    }

    @Override
    public void sendMessage(byte[] message) {
        try {
            OutputStream outputStream = mSocket.getOutputStream();
            if (outputStream != null) {
                outputStream.write(message);
            }
        } catch (IOException ex) {

            ex.printStackTrace();
        }
    }
}
