package com.lab.bluetoothlibrary;

public class RunnableThread implements Runnable {

    @Override
    public void run() {

    }
}
