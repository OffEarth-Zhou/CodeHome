package com.lab.bluetoothlibrary;

public abstract class BaseBluetoothCommunicationPresenter {

    public IBluetoothCommunicationView myBluetoothCommunicationView;
    public IBluetoothUtil myBluetoothControl;

    public abstract void init();

    public void addBluetoothCommunicationView(IBluetoothCommunicationView myBluetoothCommunicationView) {
        this.myBluetoothCommunicationView = myBluetoothCommunicationView;
    }

    public abstract void sendMessage(String message);

    public abstract void receiveMessage(int bytes, byte[] buffer);

    public abstract void startDetect();

    public abstract void stopDetect();
}
