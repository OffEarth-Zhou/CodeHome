package com.lab.bluetoothlibrary;

public interface IBluetoothCommunicationView {
    void showMessage(int length, Object buffer);
}
