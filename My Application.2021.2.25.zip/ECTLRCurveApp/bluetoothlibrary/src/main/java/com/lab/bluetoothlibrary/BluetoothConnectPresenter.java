package com.lab.bluetoothlibrary;

import java.util.ArrayList;

public class BluetoothConnectPresenter {

    private boolean isBluetoothEnable;
    private IBluetoothConnectView myBluetoothControlView;
    private IBluetoothUtil myBluetoothControl;
    private ArrayList<String> deviceNameList = new ArrayList<>();
    private int curDeviceIndex;
    private int connectStatus;
    private  INextViewAdapter myINextViewAdapter;

    public  void init(){
        this.myBluetoothControl = BluetoothControl.getInstance();
        this.myINextViewAdapter = new NextCommunicationViewAdapter();
        this.myBluetoothControl.addBluetoothConnectPresenter(this);
        this.myBluetoothControl.init();
    }

    public void addBluetoothControlView(IBluetoothConnectView myBluetoothControlView) {
        this.myBluetoothControlView = myBluetoothControlView;
    }

    public void setBluetoothEnable(boolean isBluetoothEnable) {
        this.isBluetoothEnable = isBluetoothEnable;
    }

    public boolean isBluetoothEnable() {
        return isBluetoothEnable;
    }

    public void setDeviceNameList(ArrayList<String> deviceNameList) {
        this.deviceNameList = deviceNameList;
        myBluetoothControlView.updateDeviceNameList(deviceNameList);
    }

    public void setCurDeviceIndex(int CurDeviceIndex) {
        this.curDeviceIndex = CurDeviceIndex;
        myBluetoothControl.setCurDeviceIndex(CurDeviceIndex);
    }

    public int getCurDeviceIndex() {
        return curDeviceIndex;
    }

    public void connectDevice() {
        myBluetoothControl.connenct();
    }

    public void isConnectDone(boolean status) {
        myBluetoothControlView.isConnectDone(status);
    }
}
