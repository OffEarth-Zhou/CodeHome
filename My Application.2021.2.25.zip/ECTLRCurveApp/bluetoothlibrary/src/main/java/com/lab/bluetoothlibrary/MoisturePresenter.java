package com.lab.bluetoothlibrary;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class MoisturePresenter extends  BaseBluetoothCommunicationPresenter {

    final Object lock = new Object();

    @Override
    public void init() {
        myBluetoothControl = BluetoothControl.getInstance();
        myBluetoothControl.addBluetoothCommunicationPresenter(this);
    }

    @Override
    public void sendMessage(String message) {
        myBluetoothControl.sendMessage(message);
    }

    @Override
    public void receiveMessage(int bytes, byte[] buffer) {
        try {
            AcheData(bytes, buffer);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void startDetect() {
        // ee b1 99 ff fc ff ff
//        byte[]command = {(byte) 238,};
        byte[]command = {(byte) 0xee,(byte) 0xb1,(byte) 0x99,(byte) 0xff,(byte) 0xfc,(byte) 0xff,(byte) 0xff};
        myBluetoothControl.sendMessage((command));
    }

    @Override
    public void stopDetect() {
        // ee b1 98 ff fc ff ff
        byte[]command = {(byte) 0xee,(byte) 0xb1,(byte) 0x98,(byte) 0xff,(byte) 0xfc,(byte) 0xff,(byte) 0xff};
        myBluetoothControl.sendMessage((command));
    }


        private ArrayList<Integer> myData = new ArrayList<>();

    public void AcheData(int bytes, byte[] buffer) {
        if (bytes >= 15) {
            int count = 0;
            do {
                int ccc = bytes - 7 - count;
//                if (buffer[ccc + 0] != null && buffer[ccc + 1] != null) {
                if (getUnsignByte(buffer[ccc + 0]) == 0xee && getUnsignByte(buffer[ccc + 1]) == 0xb1) {
//                        if (buffer[ccc + 3] != null && buffer[ccc + 4] != null && buffer[ccc + 5] != null && buffer[ccc + 6]!= null) {
                    int rp = getUnsignByte(buffer[ccc + 3]) + getUnsignByte(buffer[ccc + 4]) * 256;
                    int lp = getUnsignByte(buffer[ccc + 5]) + getUnsignByte(buffer[ccc + 6]) * 256;
                    myBluetoothCommunicationView.showMessage(2, new int[]{rp, lp});
                    break;
                }
//                }
                count = count + 1;
            }
            while (count < bytes - 7);
        }
    }

    private int  getUnsignByte(byte val){
        return  (int)(val&0xff);
    }
}


