package com.lab.bluetoothlibrary;

public interface INextViewAdapter {
    void action();
}
