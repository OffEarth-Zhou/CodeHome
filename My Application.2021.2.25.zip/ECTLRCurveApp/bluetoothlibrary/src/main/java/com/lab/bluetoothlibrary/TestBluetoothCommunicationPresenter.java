package com.lab.bluetoothlibrary;

import java.util.ArrayList;

public class TestBluetoothCommunicationPresenter extends  BaseBluetoothCommunicationPresenter{

    @Override
    public  void init(){
        myBluetoothControl = BluetoothControl.getInstance();
        myBluetoothControl.addBluetoothCommunicationPresenter(this);
    }

    @Override
    public void sendMessage(String message) {
        myBluetoothControl.sendMessage(message);
    }

    @Override
    public void receiveMessage(int bytes, byte[] buffer) {
        myBluetoothCommunicationView.showMessage(bytes, buffer);
    }

    @Override
    public void startDetect() {

    }

    @Override
    public void stopDetect() {

    }
}
