package com.lab.bluetoothlibrary;

public interface IMositureUtil {
    void setDetectType();
    void startDetect();
    void stopDetect();

}
