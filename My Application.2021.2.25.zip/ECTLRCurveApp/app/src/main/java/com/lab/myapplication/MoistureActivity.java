package com.lab.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TextView;

import com.lab.bluetoothlibrary.BaseBluetoothCommunicationPresenter;
import com.lab.bluetoothlibrary.IBluetoothCommunicationView;
import com.lab.bluetoothlibrary.MoisturePresenter;
import com.lab.chartlibrary.ChartService;


import java.util.Timer;

public class MoistureActivity extends AppCompatActivity implements IBluetoothCommunicationView {

    private LinearLayout mRpCurveLayout;//
    private LinearLayout mLpCurveLayout;//
    private ChartService mServiceRp;
    private ChartService mServiceLp;
    private Timer timer;
    private BaseBluetoothCommunicationPresenter myBluetoothCommunicationPresenter;
    private TabHost tabHost;

    private Button buttonStartDetect;
    private Button buttonStopDetect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moisture);

        buttonStartDetect = findViewById(R.id.buttonStartDetect);
        buttonStopDetect = findViewById(R.id.buttonStopDetect);

        buttonStartDetect.setOnClickListener(new MyClickListener());
        buttonStopDetect.setOnClickListener(new MyClickListener());

        tabHost = (TabHost) findViewById(R.id.ROrLTabHost);
        tabHost.setup();
        // 设置标签1的标题为“标签1”，且布局为LinearLayout1，须和layout中的布局文件tab1.xml同，下同理
        tabHost.addTab(tabHost.newTabSpec("").setIndicator("R曲线")
                .setContent(R.id.tab1));
        tabHost.addTab(tabHost.newTabSpec("").setIndicator("L曲线")
                .setContent(R.id.tab2));
        try {

            mRpCurveLayout = (LinearLayout) findViewById(R.id.rp_curve);
            mServiceRp = new ChartService(this);
            mServiceRp.setXYMultipleSeriesDataset("Rp曲线");
            mServiceRp.setXYMultipleSeriesRenderer(100, 65500, "", "时间", "",
                    Color.RED, Color.RED, Color.RED, Color.BLACK);
            mServiceRp.SetYRange(new double[]{0, 65500});
            //将左右图表添加到布局容器中
            mRpCurveLayout.addView(mServiceRp.getGraphicalView(), new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));

            mLpCurveLayout = (LinearLayout) findViewById(R.id.lp_curve);
            mServiceLp = new ChartService(this);
            mServiceLp.setXYMultipleSeriesDataset("Lp曲线");
            mServiceLp.setXYMultipleSeriesRenderer(100, 10000, "", "时间", "",
                    Color.RED, Color.RED, Color.RED, Color.BLACK);
            mServiceLp.SetYRange(new double[]{0, 10000});
            //将左右图表添加到布局容器中
            mLpCurveLayout.addView(mServiceLp.getGraphicalView(), new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));


            myBluetoothCommunicationPresenter = new MoisturePresenter();
            myBluetoothCommunicationPresenter.addBluetoothCommunicationView(this);
            myBluetoothCommunicationPresenter.init();


        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }


    private double t = 0;
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 0) {
                try {
                    int length = (int) msg.arg1;
                    int[] readBuf = (int[]) msg.obj;
                    mServiceRp.updateChart(t, readBuf[0]);
                    mServiceLp.updateChart(t, readBuf[1]);
                    t = t + 0.3;
                    t = t > Integer.MAX_VALUE - 3 ? 0 : t;
                    TextView show_msg0=findViewById(R.id.show_msg0);
                    String strSum0=String.valueOf(readBuf[0]);
                    show_msg0.setText(strSum0);
                    TextView show_msg1=findViewById(R.id.show_msg1);
                    String strSum1=String.valueOf(readBuf[1]);
                    show_msg1.setText(strSum1);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    };


    @Override
    public void showMessage(int length, Object buffer) {
        mHandler.obtainMessage(0, length, -1, buffer).sendToTarget();
    }

    public class MyClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            try {
                if (v.getId() == buttonStartDetect.getId()) {
                    myBluetoothCommunicationPresenter.startDetect();
                }
                else  if (v.getId() == buttonStopDetect.getId()) {
                    myBluetoothCommunicationPresenter.stopDetect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}
