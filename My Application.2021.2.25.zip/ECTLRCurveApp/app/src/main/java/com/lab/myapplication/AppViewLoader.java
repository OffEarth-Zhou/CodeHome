package com.lab.myapplication;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import com.lab.bluetoothlibrary.IViewLoader;

public class AppViewLoader extends AppCompatActivity implements  IViewLoader {
    @Override
    public void loadBluetoothConnectView(Context context) {
        try {
            Intent intent = new Intent(context, BluetoothConnectAppActivity.class);
            context.startActivity(intent);

        }
        catch (Exception ex) {
            ex.printStackTrace();
        }


    }

    @Override
    public void loadBluetoothCommunicationView() {
    }



}
