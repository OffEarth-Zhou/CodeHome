package com.lab.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.Constraints;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.PermissionChecker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.SyncStateContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.lab.bluetoothlibrary.BluetoothConnectPresenter;
import com.lab.bluetoothlibrary.IBluetoothConnectView;

import java.util.ArrayList;

public class BluetoothConnectAppActivity extends AppCompatActivity  implements IBluetoothConnectView {


    private ListView listView;//蓝牙列表
    private Button button_connectDevice;
    private BluetoothConnectPresenter myBluetoothConnectPresenter;
    private static final int STARTCONNECTBLUETOOTH = 15;
    private static final int CONNECTBLUETOOTHDONE = 16;
    private static final int REQUEST_ENABLE_BT = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkBluetoothPermission();
        setContentView(R.layout.activity_bluetooth_connect_app);
        init();
        this.myBluetoothConnectPresenter = new BluetoothConnectPresenter();
        this.myBluetoothConnectPresenter.addBluetoothControlView(this);
        this.myBluetoothConnectPresenter.init();
    }

    private void checkBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            //校验是否已具有模糊定位权限
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.BLUETOOTH,
                                Manifest.permission.BLUETOOTH_ADMIN,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        REQUEST_ENABLE_BT);
            } else {
            }
        } else {
        }
    }


    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            try {
                if (msg.what == STARTCONNECTBLUETOOTH) {
                    button_connectDevice.setText("正在连接...");
                    button_connectDevice.setEnabled(false);
                } else if (msg.what == CONNECTBLUETOOTHDONE) {
                    button_connectDevice.setEnabled(true);
                    Toast.makeText(getApplicationContext(), "蓝牙连接成功", Toast.LENGTH_SHORT).show();
                    button_connectDevice.setText("连接设备");
                    startActivity(new Intent(BluetoothConnectAppActivity.this, MoistureActivity.class));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };



    private void init() {
        listView = findViewById(R.id.listView_BluetoothDeviceNames);
        listView.setOnItemClickListener(new MyOnItemClickListener());
        button_connectDevice = findViewById(R.id.button_ConnectBluetooth);
        button_connectDevice.setOnClickListener(new MyClickListener());
    }

    @Override
    public void updateDeviceNameList(ArrayList<String> deviceNameList) {
        try {
            ArrayAdapter<String> deviceNamesArrayAdapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_expandable_list_item_1, deviceNameList);
            listView.setAdapter(deviceNamesArrayAdapter);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }

    @Override
    public void addPresenter(BluetoothConnectPresenter presenter) {
        myBluetoothConnectPresenter = presenter;
    }

    @Override
    public void isConnectDone(boolean status) {
        try {
            if (status) {
                mHandler.sendEmptyMessage(CONNECTBLUETOOTHDONE);
            } else {
                mHandler.sendEmptyMessage(STARTCONNECTBLUETOOTH);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    public class MyOnItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            try {
                if (parent.getId() == listView.getId()) {
                    myBluetoothConnectPresenter.setCurDeviceIndex(position);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public class MyClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            try {
                if (v.getId() == button_connectDevice.getId()) {
                    myBluetoothConnectPresenter.connectDevice();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }




}


