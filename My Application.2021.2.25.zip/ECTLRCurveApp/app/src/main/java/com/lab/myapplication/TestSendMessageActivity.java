package com.lab.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.lab.bluetoothlibrary.BaseBluetoothCommunicationPresenter;
import com.lab.bluetoothlibrary.IBluetoothCommunicationView;
import com.lab.bluetoothlibrary.TestBluetoothCommunicationPresenter;

public class TestSendMessageActivity extends AppCompatActivity implements IBluetoothCommunicationView {

    private EditText editText_sendMessage;
    private Button button_sendMessage;
    private EditText editText_receivedMessage;
    private BaseBluetoothCommunicationPresenter myBluetoothCommunicationPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);
        init();
        myBluetoothCommunicationPresenter = new TestBluetoothCommunicationPresenter();
        myBluetoothCommunicationPresenter.addBluetoothCommunicationView(this);
        myBluetoothCommunicationPresenter.init();
    }


    private void init() {
        editText_sendMessage = findViewById(R.id.sendMessageText);
        button_sendMessage = findViewById(R.id.button_sendMessage);
        button_sendMessage.setOnClickListener(new MyClickListener());
        editText_receivedMessage = findViewById(R.id.editTextReceivedMessage);
    }

    @Override
    public void showMessage(int length, Object buffer) {

        mHandler.obtainMessage(0, length, -1, buffer).sendToTarget();
    }

    public class MyClickListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            try {
                if (v.getId() == button_sendMessage.getId()) {
                    myBluetoothCommunicationPresenter.sendMessage(editText_sendMessage.getText().toString());
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            try {
                if (msg.what == 0) {
                    int bytes = (int) msg.arg1;
                    byte[] readBuf = (byte[]) msg.obj;
                    String readMessage="";
                    for (int i = 0;i<bytes;i++){
                        readMessage = readMessage +Integer.toHexString ((int)(readBuf[i]&0xff));
                    }
//                    String readMessage = new String(readBuf, 0, msg.arg1);
                    editText_receivedMessage.append(readMessage);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    };
}
